﻿using UnityEngine;
using System.Collections;
using System.IO.Ports;

public class PlayerPaddle : Paddle{

    SerialPort porta = new SerialPort("COM7", 9600);

    public Vector2 direction { get; private set; }

    void Start(){
        porta.Open();
        porta.ReadTimeout = 10;
    }
  
    private void Update(){      
        if(porta.IsOpen){
        string value = porta.ReadLine();
           
        if (value.Equals("ui_up")) {
            this.direction = Vector2.up;
            value = "";
        }
        if (value.Equals("ui_down")) {
            this.direction = Vector2.down;
            value = "";
        } 
        if(value.Equals("Parado")){
            this.direction = Vector2.zero;
            value = "";
        }
    }
}

    private void FixedUpdate()
    {
        if (this.direction.sqrMagnitude != 0) {
            this.rigidbody.AddForce(this.direction * this.speed);
        }
    }

}
