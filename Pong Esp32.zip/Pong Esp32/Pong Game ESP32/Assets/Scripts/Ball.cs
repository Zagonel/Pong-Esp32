﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class Ball : MonoBehaviour
{
    public float speed = 200f;
    public new Rigidbody2D rigidbody { get; private set; }

    private void Awake(){
        this.rigidbody = GetComponent<Rigidbody2D>();
    }

    public void ResetPosition()
    {
        this.rigidbody.velocity = Vector2.zero;
        this.rigidbody.position = Vector2.zero;
    }

    public void AddStartingForce()
    {
        // escolhe um numero aleatorio para ir para direita ou esquerda
        float x = Random.value < 0.5f ? -1f : 1f;

        // valor aleatorio para gerar um angulo de saida
        float y = Random.value < 0.5f ? Random.Range(-1f, -0.5f)
                                      : Random.Range(0.5f, 1f);

        Vector2 direction = new Vector2(x, y);
        this.rigidbody.AddForce(direction * this.speed);
    }

    public void AddForce(Vector2 force)
    {
        this.rigidbody.AddForce(force);
    }

}
